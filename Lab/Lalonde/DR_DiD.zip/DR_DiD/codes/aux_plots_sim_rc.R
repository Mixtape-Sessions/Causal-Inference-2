#-----------------------------------------------------------------------------
# Generate the DID estimators

dr.imp1 <- mc[,3] # Not locally efficiency
dr.tr1 <- mc[,7] # Not locally efficient
abadie.ipw <-  mc[,11]
reg <-  mc[,15] 
twfe <-  mc[,19]
abadie.std.ipw <- mc[,23]

dr.imp2 <- mc[,28] # Locally efficient
dr.tr2 <- mc[,32] # Locally efficient

# Put them in a dataframe
df <- as.data.frame(cbind(twfe, abadie.ipw, abadie.std.ipw, reg, 
                          dr.tr1, dr.imp1, dr.tr2, dr.imp2))
df.dr1 <- as.data.frame(cbind(dr.tr1, dr.imp1))

df.dr2 <- as.data.frame(cbind(dr.tr2, dr.imp2))

df.dr.reg <- as.data.frame(cbind(dr.tr1, dr.imp1, reg, dr.tr2, dr.imp2))

reg.ipw <- as.data.frame(cbind(reg, abadie.std.ipw))

#convert them to ggplot style
dr.boxplot <- melt(df.dr1)
dr2.boxplot <- melt(df.dr.reg)
dr3.boxplot <- melt(df.dr2)
dr4.boxplot <- melt(cbind(df.dr1,df.dr2))

reg.ipw.boxplot <- melt (reg.ipw)




range.gg <- range(reg, dr.imp1, dr.tr1, dr.tr2, dr.imp2)
range.gg2 <- range(reg, dr.imp1, dr.tr1, abadie.std.ipw, dr.tr2, dr.imp2)
range.gg3 <- range(dr.tr2, dr.imp2)
range.gg4 <- range(dr.tr2, dr.imp2, dr.tr1, dr.imp1)
#-----------------------------------------------------------------------------
# Plot the densities

# Theme of the plots
p.style <- theme(
  panel.background = element_rect(fill = "transparent"), # bg of the panel
  plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
  panel.grid.major = element_blank(), # get rid of major grid
  panel.grid.minor = element_blank(), # get rid of minor grid
  legend.background = element_rect(fill = "transparent"), # get rid of legend bg
  legend.box.background = element_rect(fill = "transparent"), # get rid of legend panel bg
  #legend.title = element_blank(),
  legend.title=element_text(size=9),
  legend.text=element_text(size=8),
  legend.key.size = unit(.5, "cm"))


d.twfe <- ggplot(df, aes(x = twfe)) +
  geom_density(color="black",fill="#ed6464",  alpha=.9) +
  geom_vline(xintercept = 0) + 
  p.style +
  xlim(range.gg2) +
  labs(x = "Two-Way FE Estimator", y = "Density")
  

d.reg <- ggplot(df, aes(x = reg)) +
  geom_density(color="black",fill="#fff7bc",  alpha=.9) + 
  geom_vline(xintercept = 0) + 
  p.style + 
  xlim(range.gg2) +
  labs(x = "Regression DID Estimator", y = "Density")
  

d.ipw <- ggplot(df, aes(x = abadie.ipw)) + 
  geom_density(color="black",fill="grey",  alpha=.9) + 
  geom_vline(xintercept = 0) + 
  p.style +
  xlim(range(range.gg2,abadie.ipw)) +
  labs(x = "IPW DID Estimator", y = "Density")


d.ipw.std <- ggplot(df, aes(x = abadie.std.ipw)) + 
  geom_density(color="black",fill="#feb24c", alpha = 0.9) + 
  geom_vline(xintercept = 0) +
  xlim(range.gg2) +
  p.style + 
  labs(x = "Std. IPW DID Estimator", y = "Density")


d.dr1.did <-  ggplot(dr.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c("#31a354", "#a1d99b"),
                    labels = c("DR Trad.",
                               "DR Imp.")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg2) +
  labs(x = "DR (but not loc. eff.) DID Estimators", y = "Density")

  
d.dr2.did <-  ggplot(dr3.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c( "#083dff", "#7593ff" ),
                    labels = c("DR Trad. loc. eff.",
                               "DR Imp. loc. eff.")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg3) +
  labs(x = "DR & Loc. Eff. DID Estimators", y = "Density")

d.drall.did <-  ggplot(dr4.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c( "#31a354", "#a1d99b", "#083dff", "#7593ff" ),
                    labels = c("DR Trad.",
                               "DR Imp.",
                               "DR Trad. loc. eff.",
                               "DR Imp. loc. eff.")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg2) +
  labs(x = "All DR DID Estimators", y = "Density")


d.reg.ipw <-  ggplot(reg.ipw.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c("#fff7bc", "#feb24c"),
                    labels = c("OR",
                               "Std. IPW")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg2) +
  labs(x = "", y = "Density")

d.dr22.did <-  ggplot(dr3.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c( "#083dff", "#7593ff" ),
                    labels = c("DR Trad. loc. eff.",
                               "DR Imp. loc. eff.")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg2) +
  labs(x = "DR & Loc. Eff. DID Estimators", y = "Density")


d.drall2.did <-  ggplot(dr4.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c( "#31a354", "#a1d99b", "#083dff", "#7593ff" ),
                    labels = c("DR Trad.",
                               "DR Imp.",
                               "DR Trad. loc. eff.",
                               "DR Imp. loc. eff.")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR BR",
  #                           "DR IE")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg4) +
  labs(x = "", y = "Density")
  
#my_layout <- rbind(c(1:3), c(4,NA,5))


comb.plot <- grid.arrange(d.reg, d.ipw.std, d.reg.ipw, 
                          d.dr1.did, d.dr22.did, d.drall.did,
                          #layout_matrix = my_layout,
                          nrow = 2)

ggsave(here("results/rc/plots", paste0("dgp",dgp,"-rc",".pdf")),
       plot = comb.plot, width = 12, height = 5,  bg = "transparent")


ggsave(here("results/rc/plots", paste0("dgp",dgp,"-rc-imp-eff",".pdf")),
       plot = d.dr2.did, width = 12, height = 5,  bg = "transparent")


ggsave(here("results/rc/plots", paste0("dgp",dgp,"-rc-dr",".pdf")),
       plot = d.drall2.did, width = 12, height = 5,  bg = "transparent")
