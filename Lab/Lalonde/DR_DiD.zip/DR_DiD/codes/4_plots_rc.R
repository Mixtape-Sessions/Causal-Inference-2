#---------------------------------------------------
#      Plots for the Simulation results - RC
#---------------------------------------------------
#-----------------------------------------------------------------------------
# Startup - clear memory, load packages, and set parameters
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# load the necessary libraries
library(here)
library(reshape2)
library(ggplot2)
library(ggridges)
library("RColorBrewer")
library(wesanderson)
library(gridExtra)
#-----------------------------------------------------------------------------
for (dgp in 1:4){
  # Clear memory
  rm(list=ls()[!dgp])
  # Load data for DGP1
  load(here("results", "rc","MC", 
            paste0("mc_DiD_with_X-n_1000-lambda_0.5-dgp_",dgp,".RData")))
  #do the Monte Carlo
  source(here("codes/aux_plots_sim_rc.R"))
}


