#-----------------------------------------------------------------------------
# Generate the DID estimators

dr.imp <- mc[,3]
dr.tr <- mc[,7]
abadie.ipw <-  mc[,11]
reg <-  mc[,15] 
twfe <-  mc[,19]
abadie.std.ipw <- mc[,23]

# Put them in a dataframe
df <- as.data.frame(cbind(twfe, abadie.ipw, abadie.std.ipw, reg, dr.tr, dr.imp))
df.dr <- as.data.frame(cbind(dr.tr, dr.imp))
df.dr.reg <- as.data.frame(cbind(dr.tr, dr.imp, reg))

#convert them to ggplot style
dr.boxplot <- melt(df.dr)
dr2.boxplot <- melt(df.dr.reg)

range.gg <- range(reg, dr.imp, dr.tr)
range.gg2 <- range(reg, dr.imp, dr.tr, abadie.std.ipw)
#-----------------------------------------------------------------------------
# Plot the densities


# Theme of the plots
p.style <- theme(
  panel.background = element_rect(fill = "transparent"), # bg of the panel
  plot.background = element_rect(fill = "transparent", color = NA), # bg of the plot
  panel.grid.major = element_blank(), # get rid of major grid
  panel.grid.minor = element_blank(), # get rid of minor grid
  legend.background = element_rect(fill = "transparent"), # get rid of legend bg
  legend.box.background = element_rect(fill = "transparent"), # get rid of legend panel bg
  #legend.title = element_blank(),
  legend.title=element_text(size=9),
  legend.text=element_text(size=8),
  legend.key.size = unit(.5, "cm"))


d.twfe <- ggplot(df, aes(x = twfe)) +
  geom_density(color="black",fill="#ed6464",  alpha=.9) +
  geom_vline(xintercept = 0) + 
  p.style +
  xlim(range.gg2) +
  labs(x = "Two-Way FE Estimator", y = "Density")


d.reg <- ggplot(df, aes(x = reg)) +
  geom_density(color="black",fill="#fff7bc",  alpha=.9) + 
  geom_vline(xintercept = 0) + 
  p.style + 
  xlim(range.gg) +
  labs(x = "Regression DID Estimator", y = "Density")


d.ipw <- ggplot(df, aes(x = abadie.ipw)) + 
  geom_density(color="black",fill="grey",  alpha=.9) + 
  geom_vline(xintercept = 0) + 
  p.style +
  xlim(range(range.gg2,abadie.ipw)) +
  labs(x = "IPW DID Estimator", y = "Density")


d.ipw.std <- ggplot(df, aes(x = abadie.std.ipw)) + 
  geom_density(color="black",fill="#feb24c", alpha = 0.9) + 
  geom_vline(xintercept = 0) +
  xlim(range.gg2) +
  p.style + 
  labs(x = "Std. IPW DID Estimator", y = "Density")


d.dr.did <-  ggplot(dr.boxplot, aes(x = value)) + 
  geom_density(aes(fill=variable), alpha=.9) +
  geom_vline(xintercept = 0) +
  scale_fill_manual(name = "",
                    values=c("#31a354", "#a1d99b", "#e5f5e0" ),
                    labels = c("DR Tr.",
                               "DR Imp")) +
  #scale_fill_grey(name = "",
  #                labels = c("DR Tr.",
  #                           "DR Imp")) + 
  p.style +
  theme(legend.position = c(.2, .9))+
  
  xlim(range.gg) +
  labs(x = "DR DID Estimators", y = "Density")


comb.plot <- grid.arrange(d.reg, d.dr.did, d.ipw.std, nrow = 1)

ggsave(here("results/panel/plots", paste0("dgp",dgp,".pdf")),
       plot = comb.plot, width = 12, height = 5,  bg = "transparent")
