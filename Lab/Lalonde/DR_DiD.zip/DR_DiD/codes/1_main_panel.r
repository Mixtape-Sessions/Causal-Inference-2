#---------------------------------------------------
#      Panel Data case
#      All DiD estimators
#---------------------------------------------------
#-----------------------------------------------------------------------------
# Startup - clear memory, load packages, and set parameters
# Clear memory
rm(list=ls())
#-----------------------------------------------------------------------------
# Basic parameters for the simulation - Doesn't change over setups
ncores  <- 4           # Number of cores to use in parallel
seed1   <- 1234         # Set initial seed (guaranteed reproducibility)
Xsi.ps <- .75           # pscore index (strength of common support)
nrep <- 10000           # Monte Carlo replications

#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# load the necessary libraries
# Install DRDID package
devtools::install_github("pedrohcgs/DRDID")
library(foreach)
library(doSNOW)
library(doRNG)
library(trust)
library(DRDID)
library(here)
#-----------------------------------------------------------------------------
# Source my functions
source(here("codes/aux_dgps_panel_DiD_x.R"))
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# Set seed
set.seed(seed1)
#-----------------------------------------------------------------------------
################################################################
# Run the simulations for all DGPs and all sample sizes (no bootstrap)
bboot <- F

for (nn in 3:3){
  for (dgp in 1:1){
    
    #set sample size
    if(nn==1) n <- 200
    if(nn==2) n <- 500
    if(nn==3) n <- 1000
    #if(nn==4) n <- 5000
    #if(nn==5) n <- 10000
    #do the Monte Carlo
    source(here("codes/aux_sim_panel_DiD_with_X.R"))
  }
}

